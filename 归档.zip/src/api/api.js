// import axios from 'axios'

// var qs = require('qs')
// var instance = axios.create({
//   headers: {
//     'content-type': 'application/x-www-from-urlencoded'
//   }
// })

// export const ArtcaList = params => {
//   return instance.get('/api' + '/apiList/3', qs.stringify(params)).then(res => res.data)
// }